<?php

namespace App\Http\Controllers;

use App\Models\SheekImage;
use Illuminate\Http\Request;

class SheekImageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\SheekImage  $sheekImage
     * @return \Illuminate\Http\Response
     */
    public function show(SheekImage $sheekImage)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\SheekImage  $sheekImage
     * @return \Illuminate\Http\Response
     */
    public function edit(SheekImage $sheekImage)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\SheekImage  $sheekImage
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SheekImage $sheekImage)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\SheekImage  $sheekImage
     * @return \Illuminate\Http\Response
     */
    public function destroy(SheekImage $sheekImage)
    {
        //
    }
}
