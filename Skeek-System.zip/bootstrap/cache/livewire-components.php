<?php return array (
  'bank-search' => 'App\\Http\\Livewire\\BankSearch',
  'country-search' => 'App\\Http\\Livewire\\CountrySearch',
  'edit-sheek' => 'App\\Http\\Livewire\\EditSheek',
  'search-sheek' => 'App\\Http\\Livewire\\SearchSheek',
  'sheek' => 'App\\Http\\Livewire\\Sheek',
);