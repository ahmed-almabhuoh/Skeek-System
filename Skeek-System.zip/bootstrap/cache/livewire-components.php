<?php return array (
  'bank-search' => 'App\\Http\\Livewire\\BankSearch',
  'country-banks-search' => 'App\\Http\\Livewire\\CountryBanksSearch',
  'country-search' => 'App\\Http\\Livewire\\CountrySearch',
  'edit-sheek' => 'App\\Http\\Livewire\\EditSheek',
  'option-sheek-image' => 'App\\Http\\Livewire\\OptionSheekImage',
  'search-for-paid-sheek' => 'App\\Http\\Livewire\\SearchForPaidSheek',
  'search-for-recived-sheek' => 'App\\Http\\Livewire\\SearchForRecivedSheek',
  'search-sheek' => 'App\\Http\\Livewire\\SearchSheek',
  'sheek' => 'App\\Http\\Livewire\\Sheek',
);