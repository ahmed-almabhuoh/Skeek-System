@extends('back-end.parent')

@section('title', 'TITLE HERE')
@section('location', 'PAGE LOCATION')
@section('index', 'PAGE LOCATED AT')

@section('styles')
    
@endsection

@section('aside-items')
    
@endsection

@section('content')
    
@endsection

@section('scripts')
    
@endsection