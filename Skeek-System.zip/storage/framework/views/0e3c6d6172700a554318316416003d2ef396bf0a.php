

<?php $__env->startSection('title', __('cms.paid_sheek')); ?>
<?php $__env->startSection('location', __('cms.paid_sheek')); ?>
<?php $__env->startSection('index', __('cms.index')); ?>

<?php $__env->startSection('styles'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search-for-paid-sheek', [])->html();
} elseif ($_instance->childHasBeenRendered('mnwoKX0')) {
    $componentId = $_instance->getRenderedChildComponentId('mnwoKX0');
    $componentTag = $_instance->getRenderedChildComponentTagName('mnwoKX0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('mnwoKX0');
} else {
    $response = \Livewire\Livewire::mount('search-for-paid-sheek', []);
    $html = $response->html();
    $_instance->logRenderedChild('mnwoKX0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script>
        function confirmDestroy(id, refrance) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    destoy(id, refrance);
                }
            });
        }

        function destoy(id, refrance) {
            // check-system/sheeks/{sheek}
            axios.delete('/check-system/sheeks/' + id)
                .then(function(response) {
                    // handle success
                    console.log(response);
                    refrance.closest('tr').remove();
                    showDeletingMessage(response.data);
                })
                .catch(function(error) {
                    // handle error
                    console.log(error);
                    showDeletingMessage(error.response.data);
                })
                .then(function() {
                    // always executed
                });
        }

        function showDeletingMessage(data) {
            Swal.fire({
                icon: 'success',
                title: 'Your work has been saved',
                showConfirmButton: false,
                timer: 2000
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back-end.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Skeek-System\resources\views/back-end/sheek/search-for-paid-sheek.blade.php ENDPATH**/ ?>