<div>
    
    <form id="create-form" method="POST" action="<?php echo e(route('banks.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="card-body">
            <div class="form-group">
                <label for="name"><?php echo e(__('cms.name')); ?></label>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger" style="display: inline-block; padding: 0 0 0 10px;">
                        <?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="text" name="name" class="form-control" id="name" placeholder="Enter bank name">
            </div>
            <div class="form-group">
                <label for="city"><?php echo e(__('cms.city')); ?></label>
                <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger" style="display: inline-block; padding: 0 0 0 10px;">
                        <?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="text" class="form-control" id="city" name="city" placeholder="Enter city">
            </div>
            <div class="form-group">
                <label><?php echo e(__('cms.country')); ?></label>
                <?php $__errorArgs = ['country_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger" style="display: inline-block; padding: 0 0 0 10px;">
                        <?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <select class="form-control" id="country_id" name="country_id">
                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="sheek_image"><?php echo e(__('cms.image')); ?></label>
                <?php $__errorArgs = ['sheek_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger" style="display: inline-block; padding: 0 0 0 10px;">
                        <?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="input-group">
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="sheek_image" name="sheek_image">
                        <label class="custom-file-label" for="sheek_image"><?php echo e(__('cms.select_sheek_image')); ?></label>
                    </div>
                    <div class="input-group-append">
                        <span class="input-group-text"><?php echo e(__('cms.upload')); ?></span>
                    </div>
                </div>
            </div>
            <div class="form-check">
                <?php $__errorArgs = ['active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger" style="display: inline-block; padding: 0 0 0 10px;">
                        <?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="checkbox" class="form-check-input" id="active" checked>
                <label class="form-check-label" for="active"><?php echo e(__('cms.active')); ?></label>
            </div>
        </div>
        <!-- /.card-body -->

        <div class="card-footer">
            
            <input type="submit" value="Create" class="btn btn-primary">
        </div>
    </form>
</div>
<?php /**PATH C:\wamp64\www\Skeek-System\resources\views/livewire/upload-optional-sheek-image.blade.php ENDPATH**/ ?>