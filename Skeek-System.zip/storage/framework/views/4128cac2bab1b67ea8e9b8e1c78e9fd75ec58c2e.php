

<?php $__env->startSection('title', __('cms.add_skeed')); ?>
<?php $__env->startSection('location', __('cms.add_skeed')); ?>
<?php $__env->startSection('index', __('cms.add')); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        .sheek-background {
            position: relative;
        }

        .name {
            position: absolute;
            top: 35%;
            left: 40%;
            transform: translate(-50%, -50%);
            font-size: 22px;
            font-weight: bold;
        }

        .amount-in-numbers {
            position: absolute;
            top: 42%;
            right: 4%;
            transform: translate(-50%, -50%);
            font-size: 24px;
        }

        .amount-in-letter {
            position: absolute;
            top: 43%;
            left: 40%;
            transform: translate(-50%, -50%);
            font-size: 16px;
            /*font-weight: bold;*/
        }

        .date {
            position: absolute;
            top: 55%;
            right: 25%;
            transform: translate(-50%, -50%);
            font-size: 24px;
        }

        .sheek-background img {
            width: 100%;
            height: auto;
            border: 1px solid #000;
            /* opacity: 0.3; */
        }

    </style>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sheek')->html();
} elseif ($_instance->childHasBeenRendered('I8aazXS')) {
    $componentId = $_instance->getRenderedChildComponentId('I8aazXS');
    $componentTag = $_instance->getRenderedChildComponentTagName('I8aazXS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('I8aazXS');
} else {
    $response = \Livewire\Livewire::mount('sheek');
    $html = $response->html();
    $_instance->logRenderedChild('I8aazXS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <!-- /.row -->
        </div><!-- /.containers-fluid -->
    </section>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        function store() {
            // check-system/sheeks
            let formData = new FormData();
            formData.append('beneficiary_name', document.getElementById('beneficiary_name').value);
            formData.append('amount', document.getElementById('amount').value);
            formData.append('currancy', document.getElementById('currancy').value);
            formData.append('bank_id', document.getElementById('bank_id').value);
            formData.append('desc', document.getElementById('desc').value);
            formData.append('date', document.getElementById('date').value);
            formData.append('type', document.getElementById('recived').checked ? 'recived' : 'paid');
            formData.append('underline_type', document.getElementById('underline_type').value);
            axios.post('/check-system/sheeks', formData)
                .then(function(response) {
                    // handle success
                    console.log(response);
                    toastr.success(response.data.message);
                    document.getElementById('create-form').reset();
                    window.location.href = '/check-system/sheeks';
                })
                .catch(function(error) {
                    // handle error
                    console.log(error);
                    toastr.error(error.response.data.message)
                })
                .then(function() {
                    // always executed
                });
        }
    </script>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('back-end.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Skeek-System\resources\views/back-end/sheek/add.blade.php ENDPATH**/ ?>