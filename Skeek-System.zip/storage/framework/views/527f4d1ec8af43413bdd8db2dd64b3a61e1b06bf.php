<div>
    
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Search</h3>
                            <input type="text" wire:model="searchTerm"
                                style="margin-left: 15px; width: 250px; outline: none;" />
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th><?php echo e(__('cms.beneficiary_name')); ?></th>
                                        <th><?php echo e(__('cms.bank_name')); ?></th>
                                        <th><?php echo e(__('cms.amount')); ?></th>
                                        <th><?php echo e(__('cms.date')); ?></th>
                                        <th><?php echo e(__('cms.currancy')); ?></th>
                                        <th><?php echo e(__('cms.type')); ?></th>
                                        <th><?php echo e(__('cms.desc')); ?></th>
                                        <th><?php echo e(__('cms.created_at')); ?></th>
                                        <th><?php echo e(__('cms.updated_at')); ?></th>
                                        <th><?php echo e(__('cms.settings')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <div wire:loading style="margin-left: 40%; font-size: 20px;">
                                        Loading
                                    </div>
                                    <?php $__currentLoopData = $sheeks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sheek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($sheek->id); ?></td>
                                            <td><?php echo e($sheek->beneficiary_name); ?></td>
                                            <td><?php echo e($sheek->bank->name); ?></td>
                                            <td><?php echo e($sheek->amount); ?></td>
                                            <td><?php echo e($sheek->date); ?></td>
                                            <td><?php echo e($sheek->currancy); ?></td>
                                            <td><?php echo e($sheek->type); ?></td>
                                            <td><?php echo e($sheek->desc); ?></td>
                                            <td><?php echo e($sheek->created_at->diffForHumans()); ?></td>
                                            <td><?php echo e($sheek->updated_at->diffForHumans()); ?></td>
                                            <td>
                                                <div class="btn-group">
                                                    <a href="<?php echo e(route('sheeks.edit', $sheek->id)); ?>"
                                                        class="btn btn-warning">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <button type="button"
                                                        onclick="confirmDestroy(<?php echo e($sheek->id); ?>, this)"
                                                        class="btn btn-danger">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
</div>
<?php /**PATH C:\wamp64\www\Skeek-System\resources\views/livewire/search-sheek.blade.php ENDPATH**/ ?>