

<?php $__env->startSection('title', __('cms.dashboard')); ?>
<?php $__env->startSection('location', __('cms.dashboard')); ?>
<?php $__env->startSection('index', __('cms.index')); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('aside-items'); ?>

    <li class="nav-header">Humman Recourses</li>
    <li class="nav-item">
        <a href="#" class="nav-link">
            <i class="nav-icon fa fa-globe"></i>
            <p>
                Countries
                <i class="fas fa-angle-left right"></i>
            </p>
        </a>
        <ul class="nav nav-treeview">
            <li class="nav-item">
                <a href="<?php echo e(route('countries.create')); ?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Add Country</p>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('countries.index')); ?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Browse Countries</p>
                </a>
            </li>
        </ul>
    </li>
    <li class="nav-item">
        <a href="#" class="nav-link">
            <i class="nav-icon fa fa-handshake"></i>
            <p>
                <?php echo e(__('cms.banks')); ?>

                <i class="fas fa-angle-left right"></i>
            </p>
        </a>
        <ul class="nav nav-treeview">
            <li class="nav-item">
                <a href="<?php echo e(route('banks.create')); ?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p><?php echo e(__('cms.add_bank')); ?></p>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('banks.index')); ?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p><?php echo e(__('cms.browse_banks')); ?></p>
                </a>
            </li>
        </ul>
    </li>

    <li class="nav-header">Sheeks Info</li>
    <li class="nav-item">
        <a href="#" class="nav-link">
            <i class="nav-icon fa fa-handshake"></i>
            <p>
                <?php echo e(__('cms.sheeks')); ?>

                <i class="fas fa-angle-left right"></i>
            </p>
        </a>
        <ul class="nav nav-treeview">
            <li class="nav-item">
                <a href="<?php echo e(route('sheeks.create')); ?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p><?php echo e(__('cms.add')); ?></p>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('sheeks.index')); ?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p><?php echo e(__('cms.index')); ?></p>
                </a>
            </li>
        </ul>
    </li>

    <li class="nav-header">Settings</li>
    
    <li class="nav-item">
        <a href="<?php echo e(route('password.change')); ?>" class="nav-link">
            <i class="nav-icon fas fa-edit"></i>
            <p>Change password</p>
        </a>
    </li>
    
    <li class="nav-item">
        <a href="<?php echo e(route('logout')); ?>" class="nav-link">
            <i class="nav-icon fas fa-sign-out-alt"></i>
            <p>Logout</p>
        </a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('back-end.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Skeek-System\resources\views/back-end/index.blade.php ENDPATH**/ ?>