

<?php $__env->startSection('title', __('cms.banks') . ' in ' . $country->name); ?>
<?php $__env->startSection('location', __('cms.banks') . ' in ' . $country->name); ?>
<?php $__env->startSection('index', __('cms.index')); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        
                        <div class="card-header">
                            <h3 class="card-title"><?php echo e(__('cms.banks') . ' in ' . $country->name); ?></h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th><?php echo e(__('cms.name')); ?></th>
                                        <th><?php echo e(__('cms.country')); ?></th>
                                        <th><?php echo e(__('cms.active')); ?></th>
                                        <th><?php echo e(__('cms.created_at')); ?></th>
                                        <th><?php echo e(__('cms.updated_at')); ?></th>
                                        <th><?php echo e(__('cms.settings')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($bank->id); ?></td>
                                            <td><?php echo e($bank->name); ?></td>
                                            <td><?php echo e($bank->country->name . ', ' . $bank->city); ?></td>
                                            <td><span
                                                    class="badge <?php if(!$bank->active): ?> bg-danger <?php else: ?> bg-success <?php endif; ?>"><?php echo e($bank->active_status); ?></span>
                                            </td>
                                            <td><?php echo e($bank->created_at->diffForHumans()); ?></td>
                                            <td><?php echo e($bank->updated_at->diffForHumans()); ?></td>
                                            <td>
                                                <div class="btn-group">
                                                    <a href="<?php echo e(route('banks.edit', $bank->id)); ?>"
                                                        class="btn btn-warning">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <button type="button"
                                                        onclick="confirmDestroy(<?php echo e($bank->id); ?>, this)"
                                                        class="btn btn-danger">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function confirmDestroy(id, refrance) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    destoy(id, refrance);
                }
            });
        }

        function destoy(id, refrance) {
            // check-system/banks/{bank} 
            axios.delete('/check-system/banks/' + id)
                .then(function(response) {
                    // handle success
                    console.log(response);
                    refrance.closest('tr').remove();
                    showDeletingMessage(response.data);
                })
                .catch(function(error) {
                    // handle error
                    console.log(error);
                    showDeletingMessage(error.response.data);
                })
                .then(function() {
                    // always executed
                });
        }

        function showDeletingMessage(data) {
            Swal.fire({
                icon: 'success',
                title: 'Your work has been saved',
                showConfirmButton: false,
                timer: 2000
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back-end.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Skeek-System\resources\views/back-end/banks/spacific-banks.blade.php ENDPATH**/ ?>