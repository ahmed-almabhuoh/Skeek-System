

<?php $__env->startSection('title', __('cms.edit_countries')); ?>
<?php $__env->startSection('location', __('cms.edit_countries')); ?>
<?php $__env->startSection('index', __('cms.edit')); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!-- left column -->
                <div class="col-md-12">
                    <!-- general form elements -->
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title"><?php echo e(__('cms.edit_countries')); ?></h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- form start -->
                        <form id="update-form" method="POST" action="<?php echo e(route('countries.update', $country->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="name"><?php echo e(__('cms.name')); ?></label>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger" style="display: inline-block; padding: 0 0 0 10px;">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <input type="text" class="form-control" name="name" id="name"
                                        placeholder="Enter country name" value="<?php echo e($country->name); ?>">
                                </div>
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" name="active" id="active"
                                        <?php if($country->active): ?> checked <?php endif; ?>>
                                    <label class="form-check-label" for="active"><?php echo e(__('cms.active')); ?></label>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer">
                                
                                <input type="submit" value="Update" class="btn btn-primary">
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
                <!--/.col (left) -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function applyEditingCountry() {
            // check-system/countries
            axios.put('/check-system/countries/<?php echo e($country->id); ?>', {
                    name: document.getElementById('name').value,
                    active: document.getElementById('active').checked,
                })
                .then(function(response) {
                    // handle success
                    console.log(response);
                    toastr.success(response.data.message);
                    document.getElementById('update-form').reset();
                    window.location.href = '/check-system/countries';
                })
                .catch(function(error) {
                    // handle error
                    console.log(error);
                    toastr.error(error.response.data.message)
                })
                .then(function() {
                    // always executed
                });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back-end.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Skeek-System\resources\views/back-end/countries/edit.blade.php ENDPATH**/ ?>