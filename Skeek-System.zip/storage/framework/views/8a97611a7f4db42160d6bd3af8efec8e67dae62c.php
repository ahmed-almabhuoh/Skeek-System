

<?php $__env->startSection('title', __('cms.edit_sheek')); ?>
<?php $__env->startSection('location', __('cms.edit_sheek')); ?>
<?php $__env->startSection('index', __('cms.edit')); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        .sheek-background {
            position: relative;
        }

        .name {
            position: absolute;
            top: 37%;
            left: 40%;
            transform: translate(-50%, -50%);
            font-size: 22px;
            font-weight: bold;
        }

        .amount-in-numbers {
            position: absolute;
            top: 44%;
            right: 9%;
            transform: translate(-50%, -50%);
            font-size: 24px;
        }

        .amount-in-letter {
            position: absolute;
            top: 45%;
            left: 40%;
            transform: translate(-50%, -50%);
            font-size: 16px;
            /*font-weight: bold;*/
        }

        .date {
            position: absolute;
            top: 58%;
            right: 25%;
            transform: translate(-50%, -50%);
            font-size: 24px;
        }

        .sheek-background img {
            width: 100%;
            height: auto;
            border: 1px solid #000;
            /* opacity: 0.3; */
        }
    </style>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('edit-sheek', [
                'sheek' => $sheek,
            ])->html();
} elseif ($_instance->childHasBeenRendered('geZMytt')) {
    $componentId = $_instance->getRenderedChildComponentId('geZMytt');
    $componentTag = $_instance->getRenderedChildComponentTagName('geZMytt');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('geZMytt');
} else {
    $response = \Livewire\Livewire::mount('edit-sheek', [
                'sheek' => $sheek,
            ]);
    $html = $response->html();
    $_instance->logRenderedChild('geZMytt', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
    <script>
        function update(id) {
            // check-system/sheeks
            axios.put('/check-system/sheeks/' + id, {
                    beneficiary_name: document.getElementById('beneficiary_name').value,
                    amount: document.getElementById('amount').value,
                    currancy: document.getElementById('currancy').value,
                    bank_id: document.getElementById('bank_id').value,
                    desc: document.getElementById('desc').value,
                    type: document.getElementById('recived').checked ? 'recived' : 'paid',
                    underline_type: document.getElementById('underline_type').value,
                    date: document.getElementById('date').value,
                })
                .then(function(response) {
                    // handle success
                    console.log(response);
                    toastr.success(response.data.message);
                    window.location.href = '/check-system/sheeks';
                })
                .catch(function(error) {
                    // handle error
                    console.log(error);
                    toastr.error(error.response.data.message)
                })
                .then(function() {
                    // always executed
                });
        }
    </script>

    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('back-end.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Skeek-System\resources\views/back-end/sheek/edit.blade.php ENDPATH**/ ?>