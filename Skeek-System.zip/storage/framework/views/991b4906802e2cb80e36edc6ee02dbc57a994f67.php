<div>
    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Search</h3>
                    <input type="text" wire:model="searchTerm"
                        style="margin-left: 15px; width: 250px; outline: none;" />
                    <!-- Trigger/Open The Modal -->
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <button id="myBtn" type="button">Create Country</button>

                    <!-- The Modal -->
                    <div id="myModal" class="modal">
                        <!-- Modal content -->
                        <div class="modal-content">
                            <span class="close">&times;</span>
                            <p>Create new country..</p>
                            <form id="create-form" method="POST" action="<?php echo e(route('countries.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="name"><?php echo e(__('cms.name')); ?></label>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="text-danger" style="display: inline-block; padding: 0 0 0 10px;">
                                                Enter country name please.</p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <input type="text" class="form-control" id="name" name="name"
                                            value="<?php echo e(old('name')); ?>" placeholder="Enter country name">
                                    </div>
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" id="active" name="active"
                                            checked>
                                        <label class="form-check-label" for="active"><?php echo e(__('cms.active')); ?></label>
                                    </div>
                                </div>
                                <!-- /.card-body -->

                                <div class="card-footer">
                                    <input type="submit" value="Create" class="btn btn-primary">
                                </div>
                            </form>
                        </div>
                    </div>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="width: 10px">#</th>
                                <th><?php echo e(__('cms.name')); ?></th>
                                <th><?php echo e(__('cms.bank_count')); ?></th>
                                <th><?php echo e(__('cms.active')); ?></th>
                                <th><?php echo e(__('cms.created_at')); ?></th>
                                <th><?php echo e(__('cms.updated_at')); ?></th>
                                <th><?php echo e(__('cms.settings')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <div wire:loading style="margin-left: 40%; font-size: 20px;">
                                Loading
                            </div>
                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($country->id); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('country.banks', $country->id)); ?>">
                                            <?php echo e($country->name); ?>

                                        </a>
                                    </td>
                                    
                                    <td>
                                        <a class="btn btn-app bg-danger"
                                            href="<?php echo e(route('banks.specific', $country->id)); ?>">
                                            <span class="badge bg-teal"><?php echo e($country->banks_count); ?></span>
                                            <i class="fas fa-inbox"></i> <?php echo e(__('cms.bank_count')); ?>

                                        </a>
                                    </td>
                                    <td><span
                                            class="badge <?php if(!$country->active): ?> bg-danger <?php else: ?> bg-success <?php endif; ?>"><?php echo e($country->active_status); ?></span>
                                    </td>
                                    <td><?php echo e($country->created_at->diffForHumans()); ?></td>
                                    <td><?php echo e($country->updated_at->diffForHumans()); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?php echo e(route('countries.edit', $country->id)); ?>"
                                                class="btn btn-warning">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <button type="button" onclick="confirmDestroy(<?php echo e($country->id); ?>, this)"
                                                class="btn btn-danger">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.card -->
        </div>
        <!-- /.col -->
    </div>
</div>
<?php /**PATH C:\wamp64\www\Skeek-System\resources\views/livewire/country-search.blade.php ENDPATH**/ ?>