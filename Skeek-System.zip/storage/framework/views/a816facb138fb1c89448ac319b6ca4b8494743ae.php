<?php $__env->startComponent('mail::message'); ?>
# Greedings, <?php echo e($admin->name); ?>


Welcome to sheek management system.

<?php $__env->startComponent('mail::button', ['url' => 'http://localhost:8000/auth/admin/login']); ?>
Login
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\Skeek-System\resources\views/emails/adminWelcomeEmail.blade.php ENDPATH**/ ?>