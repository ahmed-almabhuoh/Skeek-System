<div class="row">
    <!-- left column -->
    <div class="col-md-5">
        <!-- general form elements -->
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title"><?php echo e(__('cms.edit_sheek')); ?></h3>
            </div>
            <!-- /.card-header -->

            <!-- form start -->
            <form>
                <div class="card-body">
                    <div class="form-group">
                        <label for="beneficiary_name"><?php echo e(__('cms.beneficiary_name')); ?></label>
                        <input type="text" class="form-control" id="beneficiary_name"
                            placeholder="Enter Beneficiary Name" wire:model="beneficiary_name"
                            value="<?php echo e($beneficiary_name); ?>">
                    </div>

                    <div class="form-group">
                        <label for="amount"><?php echo e(__('cms.amount')); ?></label>
                        <input type="number" class="form-control" id="amount" placeholder="Enter amount number"
                            wire:model="amount" value="<?php echo e($amount); ?>">
                    </div>

                    <div class="form-group">
                        <label>Currancy</label>
                        <select class="form-control" id="currancy" wire:model="currancy">
                            <option value="Dinar"><?php echo e(__('cms.dinar')); ?>

                            </option>
                            <option value="Dollar"><?php echo e(__('cms.dollar')); ?>

                            </option>
                            <option value="Shakel"><?php echo e(__('cms.shakel')); ?>

                            </option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Country</label>
                        <select class="form-control" id="country_id" wire:model="selected_country_id">
                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drop_country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($drop_country->id); ?>"
                                    <?php if($drop_country->id == $country->id): ?> selected <?php endif; ?>><?php echo e($drop_country->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="date"><?php echo e(__('cms.date')); ?></label>
                        <input type="text" class="form-control" id="date" placeholder="Enter sheek date"
                            wire:model="date" value="<?php echo e($date); ?>">
                    </div>

                    <div class="form-group">
                        <label><?php echo e(__('cms.bank')); ?></label>
                        <select class="form-control" id="bank_id" wire:model="selected_bank_id">
                            <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drop_bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($drop_bank->id); ?>"><?php echo e($drop_bank->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Underline</label>
                        <select class="form-control" id="underline_type" wire:model="line_type">
                            <option value="1" <?php if($this->sheek->underline_type == 1): ?> selected <?php endif; ?>>//</option>
                            <option value="2" <?php if($this->sheek->underline_type == 2): ?> selected <?php endif; ?>>يصرف للمستفيد الأول
                            </option>
                            <option value="3" <?php if($this->sheek->underline_type == 3): ?> selected <?php endif; ?>>غير قابل للتداول
                            </option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="desc"><?php echo e(__('cms.desc')); ?></label>
                        <input type="text" class="form-control" id="desc" placeholder="Enter description"
                            wire:model="desc" value="<?php echo e($desc); ?>">
                    </div>

                    <label><?php echo e(__('cms.type')); ?></label>
                    <div class="form-group">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="status" id="paid"
                                <?php if($sheek->type == 'paid'): ?> checked <?php endif; ?>>
                            <label class="form-check-label"><?php echo e(__('cms.paid')); ?></label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" id="recived" name="status"
                                <?php if($sheek->type == 'recived'): ?> checked <?php endif; ?>>
                            <label class="form-check-label"><?php echo e(__('cms.recived')); ?></label>
                        </div>
                    </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                    <button type="button" onclick="update(<?php echo e($sheek->id); ?>)"
                        class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
        <!-- /.card -->
    </div>
    <!--/.col (left) -->
    <div class="col-md-7">
        <!-- Form Element sizes -->
        <div class="card card-success">
            <div class="card-header">
                <h3 class="card-title"><?php echo e(__('cms.your_sheek')); ?></h3>
            </div>
            <div class="card-body sheek-background">
                <img src="<?php echo e(Storage::url($image_name)); ?>" alt="Sheek Image" class="inspire">
                <span class="name"><?php echo e($beneficiary_name); ?></span> <br>
                <span class="amount-in-letter"><?php echo e($amount_in_word); ?></span> <br>
                <span class="amount-in-numbers"><?php echo e('#' . $amount . '#'); ?></span> <br>
                <span class="date"><?php echo e($date); ?></span>
                
                
                
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
</div>
<?php /**PATH C:\wamp64\www\Skeek-System\resources\views/livewire/edit-sheek.blade.php ENDPATH**/ ?>