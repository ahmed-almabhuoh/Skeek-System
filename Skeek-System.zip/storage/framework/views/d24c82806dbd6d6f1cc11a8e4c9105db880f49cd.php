<div>
    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Search</h3>
                    <input type="text" wire:model="searchTerm"
                        style="margin-left: 15px; width: 250px; outline: none;" />
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <table class="table table-bordered">
                        <button id="myBtn" type="button">Create Bank</button>
                        <!-- The Modal -->
                        <div id="myModal" class="modal">
                            <!-- Modal content -->
                            <div class="modal-content">
                                <span class="close">&times;</span>
                                <p>Create new Bank..</p>
                                <form id="create-form" method="POST" action="<?php echo e(route('banks.store')); ?>"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="card-body">
                                        <div class="form-group">
                                            <label for="name"><?php echo e(__('cms.name')); ?></label>
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="text-danger" style="display: inline-block; padding: 0 0 0 10px;">
                                                    <?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <input type="text" class="form-control" id="name" name="name"
                                                placeholder="Enter bank name">
                                        </div>
                                        <div class="form-group">
                                            <label for="city"><?php echo e(__('cms.city')); ?></label>
                                            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="text-danger" style="display: inline-block; padding: 0 0 0 10px;">
                                                    <?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <input type="text" class="form-control" id="city" name="city"
                                                placeholder="Enter city">
                                        </div>
                                        <div class="form-group">
                                            <label for="sheek_image"><?php echo e(__('cms.image')); ?></label>
                                            <?php $__errorArgs = ['sheek_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="text-danger" style="display: inline-block; padding: 0 0 0 10px;">
                                                    <?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <div class="input-group">
                                                <div class="custom-file">
                                                    <input type="file" class="custom-file-input" id="sheek_image"
                                                        name="sheek_image">
                                                    <label class="custom-file-label"
                                                        for="sheek_image"><?php echo e(__('cms.select_sheek_image')); ?></label>
                                                </div>
                                                <div class="input-group-append">
                                                    <span class="input-group-text"><?php echo e(__('cms.upload')); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input" id="active"
                                                name="active" checked>
                                            <label class="form-check-label"
                                                for="active"><?php echo e(__('cms.active')); ?></label>
                                        </div>
                                    </div>
                                    <!-- /.card-body -->

                                    <div class="card-footer">
                                        
                                        <input type="submit" value="Create" class="btn btn-primary">
                                    </div>
                                </form>
                            </div>
                        </div>
                        <thead>
                            <tr>
                                <th style="width: 10px">#</th>
                                <th><?php echo e(__('cms.name')); ?></th>
                                <th><?php echo e(__('cms.country')); ?></th>
                                <th><?php echo e(__('cms.active')); ?></th>
                                <th><?php echo e(__('cms.created_at')); ?></th>
                                <th><?php echo e(__('cms.updated_at')); ?></th>
                                <th><?php echo e(__('cms.settings')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <div wire:loading style="margin-left: 40%; font-size: 20px;">
                                Loading
                            </div>
                            <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($bank->id); ?></td>
                                    <td><?php echo e($bank->name); ?></td>
                                    <td><?php echo e($bank->country->name ?? 'No Country' . ', ' . $bank->city); ?></td>
                                    <td><span
                                            class="badge <?php if(!$bank->active): ?> bg-danger <?php else: ?> bg-success <?php endif; ?>"><?php echo e($bank->active_status); ?></span>
                                    </td>
                                    <td><?php echo e($bank->created_at->diffForHumans()); ?></td>
                                    <td><?php echo e($bank->updated_at->diffForHumans()); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?php echo e(route('banks.edit', $bank->id)); ?>" class="btn btn-warning">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <button type="button" onclick="confirmDestroy(<?php echo e($bank->id); ?>, this)"
                                                class="btn btn-danger">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.card -->
        </div>
        <!-- /.col -->
    </div>
</div>
<?php /**PATH C:\wamp64\www\Skeek-System\resources\views/livewire/bank-search.blade.php ENDPATH**/ ?>