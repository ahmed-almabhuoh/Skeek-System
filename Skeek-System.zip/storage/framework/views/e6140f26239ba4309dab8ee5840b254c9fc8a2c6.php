<div>
    
    <div>
        
        <h6>Upload Sheek Image</h6>

        <label class="switch">
            <input type="checkbox" wire:click="$toggle('showFileElement')">
            <span class="slider round"></span>
        </label>
        
        <div class="container mx-auto">
            <?php if($showFileElement): ?>
                <div class="form-group">
                    <label for="sheek_image"><?php echo e(__('cms.image')); ?></label>
                    <?php $__errorArgs = ['sheek_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger" style="display: inline-block; padding: 0 0 0 10px;">
                            <?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="input-group">
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" id="sheek_image" name="sheek_image">
                            <label class="custom-file-label"
                                for="sheek_image"><?php echo e(__('cms.select_sheek_image')); ?></label>
                        </div>
                        <div class="input-group-append">
                            <span class="input-group-text"><?php echo e(__('cms.upload')); ?></span>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\wamp64\www\Skeek-System\resources\views/livewire/option-sheek-image.blade.php ENDPATH**/ ?>