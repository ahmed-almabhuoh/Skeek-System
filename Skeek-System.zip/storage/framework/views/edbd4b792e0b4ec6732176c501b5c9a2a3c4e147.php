

<?php $__env->startSection('title', __('cms.edit_bank')); ?>
<?php $__env->startSection('location', __('cms.edit_bank')); ?>
<?php $__env->startSection('index', __('cms.add')); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!-- left column -->
                <div class="col-md-12">
                    <!-- general form elements -->
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title"><?php echo e(__('cms.edit_bank')); ?></h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- form start -->
                        <form id="create-form" method="POST" action="<?php echo e(route('banks.update', $bank->id)); ?>"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="name"><?php echo e(__('cms.name')); ?></label>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger" style="display: inline-block; padding: 0 0 0 10px;">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <input type="text" class="form-control" id="name" name="name"
                                        placeholder="Enter bank name" value="<?php echo e($bank->name); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="city"><?php echo e(__('cms.city')); ?></label>
                                    <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger" style="display: inline-block; padding: 0 0 0 10px;">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <input type="text" class="form-control" id="city" name="city"
                                        placeholder="Enter city" value="<?php echo e($bank->city); ?>">
                                </div>
                                <div class="form-group">
                                    <label><?php echo e(__('cms.country')); ?></label>
                                    <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger" style="display: inline-block; padding: 0 0 0 10px;">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <select class="form-control" id="country_id" name="country_id">
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country->id); ?>"
                                                <?php if($bank->country_id == $country->id): ?> selected <?php endif; ?>><?php echo e($country->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    
                                    <label for="sheek_image"><?php echo e(__('cms.image')); ?></label>
                                    <?php $__errorArgs = ['sheek_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger" style="display: inline-block; padding: 0 0 0 10px;">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <div class="input-group">
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" id="sheek_image"
                                                name="sheek_image">
                                            <label class="custom-file-label"
                                                for="sheek_image"><?php echo e(__('cms.choose_image')); ?></label>
                                        </div>
                                        <div class="input-group-append">
                                            <span class="input-group-text"><?php echo e(__('cms.upload')); ?></span>
                                        </div>
                                    </div>
                                    <div class="form-group" style="margin-top: 2%;">
                                        <center><img src="/storage/img/<?php echo e($img->img ?? ''); ?>" alt="Sheek Image"
                                                class="inspire"></center>
                                    </div>
                                </div>
                                <div class="form-check">
                                    <?php $__errorArgs = ['active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger" style="display: inline-block; padding: 0 0 0 10px;">
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <input type="checkbox" class="form-check-input" id="active" name="active"
                                        <?php if($bank->active): ?> checked <?php endif; ?>>
                                    <label class="form-check-label" for="active"><?php echo e(__('cms.active')); ?></label>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer">
                                
                                <input type="submit" value="Update" class="btn btn-primary">
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
                <!--/.col (left) -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('sheekSystem/plugins/bs-custom-file-input/bs-custom-file-input.min.js')); ?>"></script>
    <script>
        $(function() {
            bsCustomFileInput.init();
        });
    </script>
    <script>
        function applyEditBank() {
            // check-system/countries
            let formData = new FormData();
            formData.append('_method', 'PUT');
            formData.append('name', document.getElementById('name').value);
            formData.append('city', document.getElementById('city').value);
            formData.append('country_id', document.getElementById('country_id').value);
            formData.append('sheek_image', document.getElementById('sheek_image').files[0]);
            formData.append('active', document.getElementById('active').checked ? 1 : 0);
            axios.post('/check-system/banks/<?php echo e($bank->id); ?>', formData)
                .then(function(response) {
                    // handle success
                    console.log(response);
                    toastr.success(response.data.message);
                    document.getElementById('create-form').reset();
                    window.location.href = '/check-system/banks';
                })
                .catch(function(error) {
                    // handle error
                    console.log(error);
                    toastr.error(error.response.data.message)
                })
                .then(function() {
                    // always executed
                });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back-end.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Skeek-System\resources\views/back-end/banks/edit.blade.php ENDPATH**/ ?>